-- Verify that data has been inserted correctly
SELECT * FROM studios;
SELECT * FROM movies;
SELECT * FROM stars;
SELECT * FROM starsin;

-- Queries
----------

-- Conditions
-------------
-- List the movies that were made after 1980
SELECT *
FROM movies
WHERE year > 1980;

-- List the movies that were less than 150 minutes long
SELECT *
FROM movies
WHERE length < 150;

-- List the movies that were made after 1980 and were less than 150 minutes long
SELECT *
FROM movies
WHERE year > 1980 AND length < 150;

-- List the movies that either were made after 1980 or were less than 150 minutes long
SELECT *
FROM movies
WHERE year > 1980 OR length < 150;

-- List the movies that either were made after 1980 or were less than 150 minutes long and contain 'War' in the title.
SELECT *
FROM movies
WHERE (year > 1980 OR length < 150) AND title LIKE '%War%';

-- List the movies that either were made after 1980 or were less than 150 minutes long and contain 'war' (case insensitive) in the title.
SELECT *
FROM movies
WHERE (year > 1980 OR length < 150) AND LOWER(title) LIKE '%war%';

-- Ordering
-----------
-- List the movies sorted by length, shortest-first
SELECT *
FROM movies
ORDER BY length;

-- List the movies sorted by length, longest-first
SELECT *
FROM movies
ORDER BY length DESC;

-- List the movies sorted by length, longest-first, and among movies of equal length, alphabetically
SELECT *
FROM movies
ORDER BY length DESC, title;

-- List the movies that were less than 150 minutes long, sorted by length, longest-first
SELECT *
FROM movies
WHERE length < 150
ORDER BY length DESC;

-- Joining
----------
-- List all the movies along with which studio owns them
SELECT *
FROM movies M, studios S
WHERE M.owner = S.id

--or
SELECT *
FROM movies M JOIN studios S ON M.owner = S.id

-- List also the movies that are not owned by any studio
SELECT *
FROM movies M LEFT OUTER JOIN studios S ON M.owner = S.id

-- List also the studios that do not own any movie
SELECT *
FROM movies M FULL OUTER JOIN studios S ON M.owner = S.id

-- List the titles of movies owned by 'Universal Pictures'
SELECT M.title
FROM movies M, studios S
WHERE M.owner = S.id AND S.name = 'Universal Pictures';
--or
SELECT M.title
FROM movies M JOIN studios S ON M.owner = S.id
WHERE S.name = 'Universal Pictures';

-- List pairs of names of stars who acted in same movie
SELECT S1.name, S2.name
FROM stars S1, stars S2, starsin SI1, starsin SI2
WHERE SI1.star = S1.id AND SI2.star = S2.id
	AND SI1.movie = SI2.movie
	AND S1.name < S2.name;

-- List for each studio, the total number of movies owned
SELECT S.name, count(*)
FROM studios S, movies M
WHERE M.owner = S.id
GROUP BY S.name
ORDER BY count(*) DESC, S.name;
-- above query is not right since it does not list the studios that do not own any movie

-- List also the studios that do not own any movie
SELECT S.name, count(*) AS count
FROM studios S, movies M
WHERE M.owner = S.id
GROUP BY S.name
UNION
SELECT S.name, 0 AS count
FROM studios S
WHERE NOT EXISTS (
	SELECT *
	FROM movies M
	WHERE M.owner = S.id
)
ORDER BY count DESC, name;

-- or
SELECT S.name, count(M.id) AS count
FROM movies M RIGHT OUTER JOIN studios S ON M.owner = S.id
GROUP BY S.name
ORDER BY count DESC, name;


-- List for each studio, the total length of film produced.
SELECT S.name, sum(M.length) AS sum
FROM studios S, movies M
WHERE M.owner = S.id
GROUP BY S.name
UNION
SELECT S.name, 0 AS sum
FROM studios S
WHERE NOT EXISTS (
	SELECT *
	FROM movies M
	WHERE M.owner = S.id
)
ORDER BY sum DESC, name;
